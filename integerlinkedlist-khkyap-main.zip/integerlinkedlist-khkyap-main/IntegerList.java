public interface IntegerList extends List<Integer> {
    //no code needed, just a specific version of List that works with Integer values.
    //this will be easier for us to implement, because we won't have to worry about Generics.
    //You will implement the methods from List in IntegerArrayList, however, you can just replace every instance of E with Integer
    // when implmenting them in your IntegerArrayList class.
}
